from sleep_tracking_toolkit.utils import compute_sleep_score, quality_label
from .utils import compute_sleep_score


#overall_average_duration(records): 

def overall_average_duration(records):
    
    total_duration = 0
    total_segments = 0

    for record in records:
        for duration, _ in record.segments: 
            
            total_duration += duration
            total_segments += 1

    average_duration = total_duration / total_segments
     
    if not records: 
        return 0
    return round(average_duration, 2)
        
    
#best_sleep_day(records): 



def best_sleep_day(records):
    
    highest_score = float('-inf')
    best_date = None

    for record in records:
        avg_score = record.average_sleep_score()
        if avg_score > highest_score:
            highest_score = avg_score
            best_date = record.date

    return best_date

#detect_under_sleep_days(records, threshold): 


def detect_under_sleep_days(records, threshold):
    
    under_sleep_dates = []

    for record in records:
        if any(duration < threshold for duration, _ in record.segments):
            under_sleep_dates.append(record.date)

    return under_sleep_dates

#detect_spike(durations, *, threshold=2): 

def detect_spike(durations, threshold=2):
    
    for i in range(1, len(durations)):
        diff = abs(durations[i] - durations[i - 1])
        if diff >= threshold:
            return True
    return False

#duration_trend(durations): 


def duration_trend(durations):
    
    trend = []

    for i in range(1, len(durations)):
        if durations[i] > durations[i - 1]:
            trend.append("up")
        elif durations[i] < durations[i - 1]:
            trend.append("down")
        else:
            trend.append("same")

    return trend

#average_sleep_score_across_days(records): 

def average_sleep_score_across_days(records):
    
    all_scores = []

    for record in records:
        for segment in record.segments:
            duration, quality = segment
            score = compute_sleep_score(duration, quality)
            all_scores.append(score)
            if not all_scores:
             return 0

    return round(sum(all_scores) / len(all_scores), 2) 