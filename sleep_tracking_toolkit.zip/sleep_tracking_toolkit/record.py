from sleep_tracking_toolkit.utils import compute_sleep_score, quality_label
from.utils import compute_sleep_score, quality_label

class DailySleepRecord: # class creation

    def __init__(self,date, segments):
        self.date = date
        self.segments = segments

    #average_quality(): 

    def average_quality(self):
        if not self.segments:
            return 0
        
        
        total_quality_score = 0
        for segment in self.segments:
            total_quality_score += segment[1]
            number_of_segments = len(self.segments)
        return round(total_quality_score / number_of_segments, 2)
    
#total duration

def total_duration(self):
    if not self.segments:
        return 0
    
    total_sleep_hours = 0
    for segment in self.segments:
        duration = segment
        total_sleep_hours += duration
        return round(total_duration, 2)

#duration_threshold, quality_threshold

def is_restful(self, duration_threshold=7, quality_threshold=75):
    for duration, quality in self.segments:
        if duration < duration_threshold or quality < quality_threshold:
            return 0
    return True

#average sleep score

def average_sleep_score(self):
        if not self.segments:
            return 0

        total_score = 0
        for duration, quality in self.segments:
              
         total_score += compute_sleep_score(duration, quality)
         average_score = total_score / len(self.segments)
        return round(average_score, 2)

def summary(self):
        avg_quality = self.average_quality()
        total_duration = self.total_duration()
        avg_score = self.average_sleep_score()
        label = quality_label(avg_score)
        return {
            "date": self.date,
            "avg_quality": avg_quality,
            "total_duration": total_duration,
            "avg_sleep_score": avg_score,
            "quality_label": label
        }